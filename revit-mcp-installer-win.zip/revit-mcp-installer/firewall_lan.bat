@echo off
setlocal EnableExtensions
:: Adds the inbound Windows Firewall rule for pyRevit Routes (TCP 48884).
:: Only needed if Claude Desktop runs on a DIFFERENT machine (LAN access).
:: This is the ONLY step that needs admin - it self-elevates (UAC prompt).
:: Everything is logged to %TEMP%\revitmcp_firewall.log so nothing fails silently.

set "LOG=%TEMP%\revitmcp_firewall.log"

:: --- are we elevated? ---
net session >nul 2>&1
if %errorlevel% equ 0 goto :DOWORK

:: --- not elevated: relaunch elevated, keeping the console OPEN (cmd /k) ---
echo Requesting administrator rights for the firewall rule (accept the UAC prompt)...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "Start-Process -Verb RunAs -FilePath 'cmd.exe' -ArgumentList '/k','\"\"%~f0\"\"'"
if %errorlevel% neq 0 (
  echo.
  echo Could not trigger the UAC prompt automatically.
  echo Right-click firewall_lan.bat and choose "Run as administrator".
  echo.
  pause
)
exit /b

:DOWORK
echo ============================================================ > "%LOG%"
echo   pyRevit Routes firewall rule (TCP 48884)>> "%LOG%"
echo   %DATE% %TIME%>> "%LOG%"
echo ============================================================>> "%LOG%"
echo Running elevated. Log: %LOG%
echo.

:: Primary: Win11/PowerShell cmdlet (idempotent - remove any old copy first)
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "try { Get-NetFirewallRule -DisplayName 'pyRevit Routes 48884' -ErrorAction SilentlyContinue | Remove-NetFirewallRule -ErrorAction SilentlyContinue; New-NetFirewallRule -DisplayName 'pyRevit Routes 48884' -Direction Inbound -Action Allow -Protocol TCP -LocalPort 48884 -Profile Any -ErrorAction Stop | Out-Null; Write-Host '[OK] Firewall rule added via New-NetFirewallRule.' -ForegroundColor Green; exit 0 } catch { Write-Host ('[!] cmdlet failed: ' + $_.Exception.Message) -ForegroundColor Yellow; exit 1 }" 1>>"%LOG%" 2>>&1
set "RC=%errorlevel%"

if "%RC%"=="0" (
  echo [OK] Firewall rule added.
  goto :DONE
)

:: Fallback: netsh
echo cmdlet path failed, trying netsh ...>> "%LOG%"
netsh advfirewall firewall delete rule name="pyRevit Routes 48884" >nul 2>&1
netsh advfirewall firewall add rule name="pyRevit Routes 48884" dir=in action=allow protocol=TCP localport=48884 >>"%LOG%" 2>&1
if %errorlevel% equ 0 (
  echo [OK] Firewall rule added via netsh.
) else (
  echo [!] Could not add the firewall rule. See %LOG%
)

:DONE
echo.
echo --- current rule ---
netsh advfirewall firewall show rule name="pyRevit Routes 48884" 2>nul | findstr /i "Rule Name Enabled LocalPort Action Direction"
echo.
echo Full log: %LOG%
echo.
pause
endlocal
