@echo off
:: Adds the inbound Windows Firewall rule for pyRevit Routes (TCP 48884).
:: Only needed if Claude Desktop runs on a DIFFERENT machine (LAN access).
:: This is the ONLY step that needs admin - it self-elevates (UAC prompt).
:: The main installer (install_revit_mcp.bat) must be run as a normal user.

net session >nul 2>&1
if %errorlevel% neq 0 (
  echo Requesting administrator rights for the firewall rule...
  powershell -NoProfile -Command "Start-Process -Verb RunAs -FilePath '%~f0'"
  exit /b
)

netsh advfirewall firewall show rule name="pyRevit Routes 48884" >nul 2>&1
if errorlevel 1 (
  netsh advfirewall firewall add rule name="pyRevit Routes 48884" dir=in action=allow protocol=TCP localport=48884
  echo Firewall rule for inbound TCP 48884 added.
) else (
  echo Firewall rule already present.
)
echo.
pause
