# configure.ps1 — extension install + pyRevit Routes enable + Claude Desktop config
# Called by install_revit_mcp.bat. Each step is best-effort and reports status.
param(
  [string]$Token = "",
  [string]$RevitHost = "127.0.0.1",
  [string]$PyExe = "",
  [string]$ServerDir = "$env:USERPROFILE\revit-mcp"
)

function Step($n){ Write-Host "`n=== $n ===" -ForegroundColor Cyan }

$ok_ext = $false; $ok_routes = $false; $ok_claude = $false
$ExtParent = Join-Path $env:APPDATA "pyRevit\Extensions"
$Ext = Join-Path $ExtParent "RevitMCP.extension.extension"

# ---------------------------------------------------------------- 1) extension
Step "Installing the RevitMCP extension"
try {
  New-Item -ItemType Directory -Force -Path $ExtParent | Out-Null
  if (-not $Token) { throw "No GitHub token supplied (needed for the private repo)." }
  $git = Get-Command git -ErrorAction SilentlyContinue
  if ($git) {
    if (Test-Path $Ext) { Remove-Item -Recurse -Force $Ext }
    git clone "https://$Token@github.com/JacksonPinto/RevitMCP.extension.git" "$Ext" 2>&1 | Out-Null
    if (-not (Test-Path (Join-Path $Ext "startup.py"))) { throw "git clone did not produce startup.py" }
  } else {
    # no git: download the private repo zipball via the API and extract
    $zip = Join-Path $env:TEMP "revitmcp_ext.zip"
    $tmp = Join-Path $env:TEMP "revitmcp_ext_x"
    Invoke-WebRequest -Headers @{ Authorization = "token $Token"; "User-Agent" = "revitmcp" } `
      -Uri "https://api.github.com/repos/JacksonPinto/RevitMCP.extension/zipball/main" -OutFile $zip
    if (Test-Path $tmp) { Remove-Item -Recurse -Force $tmp }
    Expand-Archive -Path $zip -DestinationPath $tmp -Force
    $inner = Get-ChildItem $tmp | Select-Object -First 1
    if (Test-Path $Ext) { Remove-Item -Recurse -Force $Ext }
    Move-Item $inner.FullName $Ext
  }
  if (Test-Path (Join-Path $Ext "startup.py")) { $ok_ext = $true; Write-Host "  extension -> $Ext" }
} catch {
  Write-Host "  SKIPPED: $($_.Exception.Message)" -ForegroundColor Yellow
  Write-Host "  Add it manually in Revit: pyRevit -> Extensions -> paste the Git URL + your token."
}

# ---------------------------------------------------------------- 2) Routes on
Step "Enabling pyRevit Routes (port 48884, host 0.0.0.0)"
try {
  $ini = Join-Path $env:APPDATA "pyRevit\pyRevit_config.ini"
  New-Item -ItemType Directory -Force -Path (Split-Path $ini) | Out-Null
  $lines = @()
  if (Test-Path $ini) { $lines = Get-Content $ini }
  $out = New-Object System.Collections.ArrayList
  $inRoutes = $false; $seenRoutes = $false
  $set = @{ "enabled" = "true"; "host" = "0.0.0.0"; "port" = "48884" }
  $written = @{}
  foreach ($ln in $lines) {
    if ($ln -match '^\s*\[(.+)\]\s*$') {
      if ($inRoutes) { foreach ($k in $set.Keys) { if (-not $written[$k]) { [void]$out.Add("$k = $($set[$k])") } } }
      $inRoutes = ($Matches[1] -eq 'routes'); if ($inRoutes) { $seenRoutes = $true; $written = @{} }
      [void]$out.Add($ln); continue
    }
    if ($inRoutes -and $ln -match '^\s*([A-Za-z0-9_]+)\s*=') {
      $key = $Matches[1].ToLower()
      if ($set.ContainsKey($key)) { [void]$out.Add("$key = $($set[$key])"); $written[$key] = $true; continue }
    }
    [void]$out.Add($ln)
  }
  if ($inRoutes) { foreach ($k in $set.Keys) { if (-not $written[$k]) { [void]$out.Add("$k = $($set[$k])") } } }
  if (-not $seenRoutes) {
    [void]$out.Add("[routes]")
    foreach ($k in $set.Keys) { [void]$out.Add("$k = $($set[$k])") }
  }
  Set-Content -Path $ini -Value $out -Encoding UTF8
  $ok_routes = $true; Write-Host "  wrote [routes] enabled/host/port in $ini"
  Write-Host "  (verify in pyRevit -> Settings -> Routes after Reload)"
} catch {
  Write-Host "  Could not edit pyRevit_config.ini: $($_.Exception.Message)" -ForegroundColor Yellow
  Write-Host "  Enable it manually: pyRevit -> Settings -> Routes -> on, port 48884."
}

# ---------------------------------------------------------------- 3) Claude cfg
Step "Writing Claude Desktop config"
try {
  if (-not $PyExe) { $PyExe = (Get-Command py -ErrorAction SilentlyContinue).Source }
  $srv = Join-Path $ServerDir "revit_mcp_server.py"
  $dir = Join-Path $env:APPDATA "Claude"
  New-Item -ItemType Directory -Force -Path $dir | Out-Null
  $cfgPath = Join-Path $dir "claude_desktop_config.json"
  if (Test-Path $cfgPath) {
    try { $cfg = Get-Content $cfgPath -Raw | ConvertFrom-Json } catch { $cfg = [pscustomobject]@{} }
  } else { $cfg = [pscustomobject]@{} }
  if (-not ($cfg.PSObject.Properties.Name -contains 'mcpServers')) {
    $cfg | Add-Member -NotePropertyName mcpServers -NotePropertyValue ([pscustomobject]@{}) -Force
  }
  $revit = [pscustomobject]@{
    command = $PyExe
    args    = @($srv)
    env     = [pscustomobject]@{ REVIT_HOST = $RevitHost; REVIT_PORT = "48884" }
  }
  $cfg.mcpServers | Add-Member -NotePropertyName revit -NotePropertyValue $revit -Force
  ($cfg | ConvertTo-Json -Depth 12) | Set-Content -Path $cfgPath -Encoding UTF8
  $ok_claude = $true
  Write-Host "  updated $cfgPath (server 'revit', REVIT_HOST=$RevitHost)"
} catch {
  Write-Host "  Could not write Claude config: $($_.Exception.Message)" -ForegroundColor Yellow
}

Write-Host "`n---- configure.ps1 summary ----"
Write-Host ("  extension : " + ($(if($ok_ext){"OK"}else{"manual"})))
Write-Host ("  routes    : " + ($(if($ok_routes){"written (verify in GUI)"}else{"manual"})))
Write-Host ("  claude cfg: " + ($(if($ok_claude){"OK"}else{"manual"})))
