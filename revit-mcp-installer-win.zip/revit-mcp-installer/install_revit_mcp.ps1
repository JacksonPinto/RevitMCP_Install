# =====================================================================
#  Revit MCP Server - per-user Windows installer (PowerShell)
#  Run as a NORMAL user (NOT elevated). pyRevit installs per-user.
#  Everything is logged to %TEMP%\revitmcp_install.log so nothing fails silently.
#
#  install_revit_mcp.bat [token] [revit_host]   (the .bat just launches this)
# =====================================================================
param(
  [string]$Token = "",
  [string]$RevitHost = "127.0.0.1"
)
$ErrorActionPreference = "Continue"
$log = Join-Path $env:TEMP "revitmcp_install.log"
try { Start-Transcript -Path $log -Force | Out-Null } catch {}

function Info($m){ Write-Host "[*]  $m" -ForegroundColor Cyan }
function Ok($m){   Write-Host "[OK] $m" -ForegroundColor Green }
function Warn($m){ Write-Host "[!]  $m" -ForegroundColor Yellow }

Write-Host "============================================================"
Write-Host "  Revit MCP Server - per-user setup   (host: $RevitHost)"
Write-Host "  Log: $log"
Write-Host "============================================================"

# soft note if elevated (do NOT block - some accounts are admin with UAC off,
# but pyRevit still installs to the user profile)
$id = [Security.Principal.WindowsIdentity]::GetCurrent()
$pr = New-Object Security.Principal.WindowsPrincipal($id)
if ($pr.IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)) {
  Warn "This process is elevated. pyRevit is best installed per-user; if pyRevit"
  Warn "misbehaves, re-run this WITHOUT 'Run as administrator'."
}

$work = Join-Path $env:TEMP "revitmcp_setup"; New-Item -ItemType Directory -Force -Path $work | Out-Null
$srv  = Join-Path $env:USERPROFILE "revit-mcp"; New-Item -ItemType Directory -Force -Path $srv | Out-Null
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $Token) { $Token = Read-Host "GitHub access token for the private extension (Enter to skip)" }

# ---------------------------------------------------------------- 1) Python
Info "Downloading Python 3.12.10 ..."
$pyUrl = "https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe"
$pySetup = Join-Path $work "python-3.12.10-amd64.exe"
try { Invoke-WebRequest -Uri $pyUrl -OutFile $pySetup -UseBasicParsing } catch { Warn "Python download failed: $($_.Exception.Message)" }
if (Test-Path $pySetup) {
  Info "Installing Python (per-user, silent) ..."
  $p = Start-Process -FilePath $pySetup -ArgumentList "/quiet","InstallAllUsers=0","PrependPath=1","Include_pip=1","Include_launcher=1" -Wait -PassThru
  if ($p.ExitCode -eq 0) { Ok "Python installed" } else { Warn "Python installer exit code $($p.ExitCode)" }
}
# resolve python.exe
$py = Join-Path $env:LOCALAPPDATA "Programs\Python\Python312\python.exe"
if (-not (Test-Path $py)) { $c = Get-Command python -ErrorAction SilentlyContinue; if ($c) { $py = $c.Source } }
if (-not (Test-Path $py)) { $py = "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe" }
Info "Python: $py"

# ---------------------------------------------------------------- 2) pyRevit (per-user)
Info "Fetching latest signed pyRevit ..."
try {
  $r = Invoke-RestMethod -Headers @{'User-Agent'='revitmcp'} 'https://api.github.com/repos/pyrevitlabs/pyRevit/releases/latest'
  $a = $r.assets | Where-Object { $_.name -match 'signed\.exe$' -and $_.name -notmatch 'admin|CLI' } | Select-Object -First 1
  if (-not $a) { $a = $r.assets | Where-Object { $_.name -match '\.exe$' } | Select-Object -First 1 }
  $pyrevitExe = Join-Path $work $a.name
  Info "Downloading $($a.name) ..."
  Invoke-WebRequest -Uri $a.browser_download_url -OutFile $pyrevitExe -UseBasicParsing
  Info "Installing pyRevit (per-user, silent) ..."
  $q = Start-Process -FilePath $pyrevitExe -ArgumentList "/VERYSILENT","/SUPPRESSMSGBOXES","/NORESTART" -Wait -PassThru
  if ($q.ExitCode -eq 0) { Ok "pyRevit installed" } else { Warn "pyRevit installer exit code $($q.ExitCode) - if it needs a per-user choice, run $pyrevitExe manually" }
} catch { Warn "pyRevit step failed: $($_.Exception.Message). Install manually from https://github.com/pyrevitlabs/pyRevit/releases" }

# ---------------------------------------------------------------- 3) mcp package
Info "Installing Python dependency (mcp) ..."
& $py -m pip install --upgrade pip
& $py -m pip install --upgrade "mcp>=1.2.0,<2"   # v1 API (mcp 2.x renamed FastMCP)
if ($LASTEXITCODE -eq 0) { Ok "mcp installed" } else { Warn "pip returned $LASTEXITCODE" }

# ---------------------------------------------------------------- 4) MCP bridge
Copy-Item (Join-Path $here "revit_mcp_server.py") $srv -Force
Copy-Item (Join-Path $here "claude_desktop_config.sample.json") $srv -Force -ErrorAction SilentlyContinue
Ok "MCP bridge copied to $srv"

# ---------------------------------------------------------------- 5) extension
Info "Installing the RevitMCP extension ..."
try {
  & (Join-Path $here "install_extension.ps1") -Token $Token | Out-Null
} catch { Warn "extension step error: $($_.Exception.Message)" }
if (Test-Path (Join-Path $env:APPDATA "pyRevit\Extensions\RevitMCP.extension.extension\startup.py")) {
  Ok "extension present"
} else {
  Warn "extension NOT installed - re-run install_extension.bat <token>, or add it via pyRevit -> Extensions."
}

# ---------------------------------------------------------------- 6) Routes on
Info "Enabling pyRevit Routes (port 48884, host 0.0.0.0) ..."
try {
  $ini = Join-Path $env:APPDATA "pyRevit\pyRevit_config.ini"
  New-Item -ItemType Directory -Force -Path (Split-Path $ini) | Out-Null
  $lines = @(); if (Test-Path $ini) { $lines = Get-Content $ini }
  $out = New-Object System.Collections.ArrayList
  $set = [ordered]@{ enabled="true"; host="0.0.0.0"; port="48884" }
  $inRoutes=$false; $seen=$false; $written=@{}
  foreach ($ln in $lines) {
    if ($ln -match '^\s*\[(.+)\]\s*$') {
      if ($inRoutes) { foreach ($k in $set.Keys) { if (-not $written[$k]) { [void]$out.Add("$k = $($set[$k])") } } }
      $inRoutes = ($Matches[1] -eq 'routes'); if ($inRoutes) { $seen=$true; $written=@{} }
      [void]$out.Add($ln); continue
    }
    if ($inRoutes -and $ln -match '^\s*([A-Za-z0-9_]+)\s*=') {
      $key = $Matches[1].ToLower()
      if ($set.Contains($key)) { [void]$out.Add("$key = $($set[$key])"); $written[$key]=$true; continue }
    }
    [void]$out.Add($ln)
  }
  if ($inRoutes) { foreach ($k in $set.Keys) { if (-not $written[$k]) { [void]$out.Add("$k = $($set[$k])") } } }
  if (-not $seen) { [void]$out.Add("[routes]"); foreach ($k in $set.Keys) { [void]$out.Add("$k = $($set[$k])") } }
  Set-Content -Path $ini -Value $out -Encoding UTF8
  Ok "Routes written to $ini (verify in pyRevit -> Settings -> Routes)"
} catch { Warn "could not edit pyRevit_config.ini: $($_.Exception.Message); enable Routes in the GUI." }

# ---------------------------------------------------------------- 7) Claude config
Info "Writing Claude Desktop config ..."
try {
  & (Join-Path $here "configure_claude.ps1") -PyExe $py -RevitHost $RevitHost -ServerDir $srv
} catch { Warn "could not write Claude config: $($_.Exception.Message)" }

# ---------------------------------------------------------------- 8) firewall (LAN only, needs admin)
Info "Firewall rule (LAN only) ..."
try {
  New-NetFirewallRule -DisplayName "pyRevit Routes 48884" -Direction Inbound -Action Allow -Protocol TCP -LocalPort 48884 -Profile Any -ErrorAction Stop | Out-Null
  Ok "Firewall rule added"
} catch { Warn "firewall rule not added (needs admin; only required for LAN). Run firewall_lan.bat if Claude is on another PC." }

Write-Host ""
Write-Host "============================================================" -ForegroundColor Green
Write-Host "  Done. Two steps that need the apps running:"
Write-Host "   A) Open Revit -> pyRevit -> Reload; verify http://localhost:48884/revit/ping"
Write-Host "   B) Fully restart Claude Desktop, then ask: ping revit"
Write-Host "  Full log: $log"
Write-Host "============================================================" -ForegroundColor Green
try { Stop-Transcript | Out-Null } catch {}
