@echo off
setlocal
:: Installs ONLY the private RevitMCP extension (run as a normal user).
:: Use this if the main installer skipped/failed the extension step.
:: Usage:  install_extension.bat [github_token]
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_extension.ps1" -Token "%~1"
echo.
pause
endlocal
