# Writes/merges the "revit" MCP server into Claude Desktop's config.
# Fixes: writes UTF-8 WITHOUT BOM (Claude fails to parse a BOM) and always
# emits args as a JSON array. Keeps any existing mcpServers (e.g. qsys-designer).
# Usage:  configure_claude.ps1 -PyExe <python.exe> -RevitHost 127.0.0.1 -ServerDir "%USERPROFILE%\revit-mcp"
param(
  [string]$PyExe = "",
  [string]$RevitHost = "127.0.0.1",
  [string]$ServerDir = "$env:USERPROFILE\revit-mcp"
)
$ErrorActionPreference = "Continue"
function Ok($m){ Write-Host "[OK] $m" -ForegroundColor Green }
function Warn($m){ Write-Host "[!]  $m" -ForegroundColor Yellow }

# resolve python if not given
if (-not $PyExe) {
  $PyExe = Join-Path $env:LOCALAPPDATA "Programs\Python\Python312\python.exe"
  if (-not (Test-Path $PyExe)) { $c = Get-Command python -ErrorAction SilentlyContinue; if ($c) { $PyExe = $c.Source } }
}
$serverPath = Join-Path $ServerDir "revit_mcp_server.py"
if (-not (Test-Path $serverPath)) { Warn "revit_mcp_server.py not found at $serverPath (continuing anyway)" }

$dir = Join-Path $env:APPDATA "Claude"
New-Item -ItemType Directory -Force -Path $dir | Out-Null
$cfgPath = Join-Path $dir "claude_desktop_config.json"

# load existing config (preserve other servers) or start fresh
$cfg = $null
if (Test-Path $cfgPath) {
  try { $cfg = Get-Content $cfgPath -Raw | ConvertFrom-Json } catch { Warn "existing config was not valid JSON - it will be rebuilt"; $cfg = $null }
}
if ($null -eq $cfg) { $cfg = [pscustomobject]@{} }
if (-not ($cfg.PSObject.Properties.Name -contains 'mcpServers') -or $null -eq $cfg.mcpServers) {
  $cfg | Add-Member -NotePropertyName mcpServers -NotePropertyValue ([pscustomobject]@{}) -Force
}

# the "," forces a single-element ARRAY so args never collapses to a string
$revit = [pscustomobject]@{
  command = $PyExe
  args    = ,$serverPath
  env     = [pscustomobject]@{ REVIT_HOST = $RevitHost; REVIT_PORT = "48884" }
}
$cfg.mcpServers | Add-Member -NotePropertyName revit -NotePropertyValue $revit -Force

try {
  $json = $cfg | ConvertTo-Json -Depth 20
  # UTF-8 WITHOUT BOM
  [System.IO.File]::WriteAllText($cfgPath, $json, (New-Object System.Text.UTF8Encoding($false)))
  Ok "Claude config written (UTF-8 no BOM): $cfgPath"
  Write-Host "--- revit entry ---" -ForegroundColor Cyan
  Write-Host ("  command : " + $PyExe)
  Write-Host ("  args    : " + $serverPath)
  Write-Host ("  env     : REVIT_HOST=" + $RevitHost + "  REVIT_PORT=48884")
  Write-Host "Restart Claude Desktop fully (quit + reopen), then ask: ping revit"
} catch {
  Warn "could not write Claude config: $($_.Exception.Message)"
}
