# Installs ONLY the private RevitMCP extension into the pyRevit extensions folder.
# Robust: tries git (if present) then a curl.exe zipball download (no git needed).
# Usage:  install_extension.ps1 -Token ghp_xxxx
param([string]$Token = "")
$ErrorActionPreference = "Continue"

function Ok($m){ Write-Host "[OK] $m" -ForegroundColor Green }
function Warn($m){ Write-Host "[!]  $m" -ForegroundColor Yellow }
function Info($m){ Write-Host "[*]  $m" -ForegroundColor Cyan }

if (-not $Token) { $Token = Read-Host "GitHub access token (read access to RevitMCP.extension)" }
if (-not $Token) { Warn "No token given - cannot install the private extension."; return $false }

$ExtParent = Join-Path $env:APPDATA "pyRevit\Extensions"
$Ext = Join-Path $ExtParent "RevitMCP.extension.extension"
$startup = Join-Path $Ext "startup.py"
New-Item -ItemType Directory -Force -Path $ExtParent | Out-Null
Info "Target: $Ext"

$done = $false

# --- method 1: git clone (if git is available) ---
$git = Get-Command git -ErrorAction SilentlyContinue
if ($git) {
  Info "Cloning with git ..."
  if (Test-Path $Ext) { Remove-Item -Recurse -Force $Ext }
  & git clone "https://$Token@github.com/JacksonPinto/RevitMCP.extension.git" "$Ext" 2>&1 | Write-Host
  if (Test-Path $startup) { $done = $true }
  else { Warn "git clone did not produce startup.py; trying zipball ..." }
}

# --- method 2: curl.exe zipball (no git needed) ---
if (-not $done) {
  $zip = Join-Path $env:TEMP "revitmcp_ext.zip"
  $tmp = Join-Path $env:TEMP "revitmcp_ext_x"
  if (Test-Path $zip) { Remove-Item -Force $zip }
  if (Test-Path $tmp) { Remove-Item -Recurse -Force $tmp }
  Info "Downloading zipball via curl.exe ..."
  & curl.exe -L -sS -H "Authorization: token $Token" -H "User-Agent: revitmcp" `
      -o "$zip" "https://api.github.com/repos/JacksonPinto/RevitMCP.extension/zipball/main"
  if (Test-Path $zip) {
    # detect an API error (JSON) instead of a zip
    $head = ([System.IO.File]::ReadAllBytes($zip) | Select-Object -First 2)
    if (-not ($head.Count -ge 2 -and $head[0] -eq 0x50 -and $head[1] -eq 0x4B)) {
      Warn "Download was not a ZIP. Server said:"
      Get-Content $zip -Raw | Select-Object -First 1 | Write-Host
      Warn "Check the token has READ access to JacksonPinto/RevitMCP.extension."
    } else {
      try {
        Expand-Archive -Path $zip -DestinationPath $tmp -Force
        $inner = Get-ChildItem $tmp -Directory | Select-Object -First 1
        if ($inner) {
          if (Test-Path $Ext) { Remove-Item -Recurse -Force $Ext }
          Move-Item $inner.FullName $Ext
        }
        if (Test-Path $startup) { $done = $true }
      } catch { Warn "extract/move failed: $($_.Exception.Message)" }
    }
  } else { Warn "curl produced no file (network/proxy?)." }
}

if ($done) {
  Ok "Extension installed: $Ext"
  Write-Host "Next: open Revit -> pyRevit tab -> Reload, then verify http://localhost:48884/revit/ping" -ForegroundColor Green
  return $true
} else {
  Warn "Extension NOT installed."
  Write-Host "Manual fallback: Revit -> pyRevit -> Extensions -> paste Git URL"
  Write-Host "  https://github.com/JacksonPinto/RevitMCP.extension.git   + your token, Add and install."
  return $false
}
