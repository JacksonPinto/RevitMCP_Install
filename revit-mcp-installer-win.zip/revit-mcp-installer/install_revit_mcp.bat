@echo off
setlocal EnableDelayedExpansion
title Revit MCP Server - Windows Installer
color 0B

:: =====================================================================
::  Revit MCP Server - full automated Windows setup
::  Installs Python 3.12.10 + latest pyRevit, the mcp package, the MCP
::  bridge, a firewall rule, THEN installs the private extension, enables
::  pyRevit Routes, and writes the Claude Desktop config (via configure.ps1).
::
::  Run as Administrator:
::     install_revit_mcp.bat  [github_token]  [revit_host]
::       github_token : token for the private extension (prompted if omitted)
::       revit_host   : Claude->Revit host (default 127.0.0.1; use the Revit
::                      PC's LAN IP if Claude Desktop runs on another machine)
::  Token: request from jackson.pinto@wwt.com
:: =====================================================================

net session >nul 2>&1
if %errorlevel% neq 0 ( echo. & echo   Right-click this file and "Run as administrator". & echo. & pause & exit /b 1 )

set "TOKEN=%~1"
set "RHOST=%~2"
if "%RHOST%"=="" set "RHOST=127.0.0.1"
if "%TOKEN%"=="" set /p "TOKEN=Enter GitHub access token for the extension (blank = add it manually later): "

set "WORK=%TEMP%\revitmcp_setup"
if not exist "%WORK%" mkdir "%WORK%"
set "PYVER=3.12.10"
set "PY_URL=https://www.python.org/ftp/python/%PYVER%/python-%PYVER%-amd64.exe"
set "PY_SETUP=%WORK%\python-%PYVER%-amd64.exe"
set "SRVDIR=%USERPROFILE%\revit-mcp"

echo ============================================================
echo   Revit MCP Server - automated Windows setup
echo   host for Claude config: %RHOST%
echo ============================================================

:: 1) Python
echo [1/7] Downloading Python %PYVER% ...
curl.exe -L --fail -o "%PY_SETUP%" "%PY_URL%"
if not exist "%PY_SETUP%" powershell -NoProfile -Command "Invoke-WebRequest -Uri '%PY_URL%' -OutFile '%PY_SETUP%'"
if not exist "%PY_SETUP%" ( echo   ERROR: Python download failed. & pause & exit /b 1 )
echo [2/7] Installing Python %PYVER% (silent) ...
"%PY_SETUP%" /quiet InstallAllUsers=0 PrependPath=1 Include_pip=1 Include_launcher=1

:: resolve the real python.exe path (for pip + Claude config)
set "PY_EXE="
for /f "delims=" %%i in ('py -3.12 -c "import sys;print(sys.executable)" 2^>nul') do set "PY_EXE=%%i"
if "%PY_EXE%"=="" set "PY_EXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"

:: 3) pyRevit (latest signed)
echo [3/7] Downloading + installing latest pyRevit (signed) ...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Stop';" ^
  "$r=Invoke-RestMethod -Headers @{'User-Agent'='revitmcp'} 'https://api.github.com/repos/pyrevitlabs/pyRevit/releases/latest';" ^
  "$a=$r.assets|?{$_.name -match 'signed\.exe$' -and $_.name -notmatch 'admin|CLI'}|select -First 1;" ^
  "if(-not $a){$a=$r.assets|?{$_.name -match '\.exe$'}|select -First 1};" ^
  "Write-Host ('   '+$a.name); Invoke-WebRequest $a.browser_download_url -OutFile '%WORK%\pyrevit_setup.exe'"
if exist "%WORK%\pyrevit_setup.exe" ( "%WORK%\pyrevit_setup.exe" /VERYSILENT /SUPPRESSMSGBOXES /NORESTART ) else ( echo   WARNING: pyRevit download failed - install manually from github.com/pyrevitlabs/pyRevit/releases )

:: 4) mcp package
echo [4/7] Installing Python dependency (mcp) ...
"%PY_EXE%" -m pip install --upgrade pip
"%PY_EXE%" -m pip install --upgrade "mcp>=1.2.0"

:: 5) MCP bridge script
echo [5/7] Installing MCP bridge to %SRVDIR% ...
if not exist "%SRVDIR%" mkdir "%SRVDIR%"
copy /Y "%~dp0revit_mcp_server.py" "%SRVDIR%\" >nul
copy /Y "%~dp0claude_desktop_config.sample.json" "%SRVDIR%\" >nul

:: 6) firewall
echo [6/7] Adding Windows Firewall rule (inbound TCP 48884) ...
netsh advfirewall firewall show rule name="pyRevit Routes 48884" >nul 2>&1
if errorlevel 1 netsh advfirewall firewall add rule name="pyRevit Routes 48884" dir=in action=allow protocol=TCP localport=48884

:: 7) extension + routes + claude config (PowerShell does the heavy lifting)
echo [7/7] Installing extension, enabling Routes, writing Claude config ...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0configure.ps1" -Token "%TOKEN%" -RevitHost "%RHOST%" -PyExe "%PY_EXE%" -ServerDir "%SRVDIR%"

echo.
echo ============================================================
echo   Almost done - two steps that require the apps running:
echo ============================================================
echo   A) Open Revit, then pyRevit tab -^> Reload  (loads the extension
echo      and starts the Routes server). Verify: http://localhost:48884/revit/ping
echo   B) Fully restart Claude Desktop, then ask it:  ping revit
echo.
echo   If the extension step was skipped (no token), add it in
echo   pyRevit -^> Extensions with the Git URL + your token.
echo ============================================================
pause
endlocal
