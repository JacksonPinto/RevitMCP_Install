@echo off
setlocal EnableDelayedExpansion
title Revit MCP Server - Windows Installer (per-user)
color 0B

:: =====================================================================
::  Revit MCP Server - full automated Windows setup  (RUN AS NORMAL USER)
::
::  IMPORTANT: do NOT run this as Administrator. pyRevit must install
::  per-user; elevating breaks it. Just double-click, or run from a normal
::  (non-elevated) command prompt.
::
::  Installs: Python 3.12.10 (per-user) + latest pyRevit (per-user) + the
::  mcp package + the MCP bridge, then installs the private extension,
::  enables pyRevit Routes, and writes the Claude Desktop config.
::  The firewall rule (LAN only) is handled separately by firewall_lan.bat.
::
::  Usage (normal user):
::     install_revit_mcp.bat  [github_token]  [revit_host]
::       github_token : token for the private extension (prompted if omitted)
::       revit_host   : Claude->Revit host (default 127.0.0.1; use the Revit
::                      PC's LAN IP if Claude Desktop runs on another machine)
::  Token: request from jackson.pinto@wwt.com
:: =====================================================================

:: --- refuse to run elevated (pyRevit would install for the wrong context) ---
net session >nul 2>&1
if %errorlevel% equ 0 (
  echo.
  echo   *** Do NOT run this as Administrator. ***
  echo   pyRevit installs per-user and will not work if this runs elevated.
  echo   Close this window and run the file normally (double-click / plain cmd).
  echo.
  pause & exit /b 1
)

set "TOKEN=%~1"
set "RHOST=%~2"
if "%RHOST%"=="" set "RHOST=127.0.0.1"
if "%TOKEN%"=="" set /p "TOKEN=Enter GitHub access token for the extension (blank = add it manually later): "

set "WORK=%TEMP%\revitmcp_setup"
if not exist "%WORK%" mkdir "%WORK%"
set "PYVER=3.12.10"
set "PY_URL=https://www.python.org/ftp/python/%PYVER%/python-%PYVER%-amd64.exe"
set "PY_SETUP=%WORK%\python-%PYVER%-amd64.exe"
set "SRVDIR=%USERPROFILE%\revit-mcp"

echo ============================================================
echo   Revit MCP Server - per-user setup   (host: %RHOST%)
echo ============================================================

:: 1) Python (per-user)
echo [1/7] Downloading Python %PYVER% ...
curl.exe -L --fail -o "%PY_SETUP%" "%PY_URL%"
if not exist "%PY_SETUP%" powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri '%PY_URL%' -OutFile '%PY_SETUP%'"
if not exist "%PY_SETUP%" ( echo   ERROR: Python download failed. & pause & exit /b 1 )
echo [2/7] Installing Python %PYVER% (per-user, silent) ...
"%PY_SETUP%" /quiet InstallAllUsers=0 PrependPath=1 Include_pip=1 Include_launcher=1

:: resolve the real python.exe path
set "PY_EXE="
for /f "delims=" %%i in ('py -3.12 -c "import sys;print(sys.executable)" 2^>nul') do set "PY_EXE=%%i"
if "%PY_EXE%"=="" set "PY_EXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"

:: 3) pyRevit (per-user - NOT elevated)
echo [3/7] Downloading + installing latest pyRevit (per-user, signed) ...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Stop';" ^
  "$r=Invoke-RestMethod -Headers @{'User-Agent'='revitmcp'} 'https://api.github.com/repos/pyrevitlabs/pyRevit/releases/latest';" ^
  "$a=$r.assets|?{$_.name -match 'signed\.exe$' -and $_.name -notmatch 'admin|CLI'}|select -First 1;" ^
  "if(-not $a){$a=$r.assets|?{$_.name -match '\.exe$'}|select -First 1};" ^
  "Write-Host ('   '+$a.name); Invoke-WebRequest $a.browser_download_url -OutFile '%WORK%\pyrevit_setup.exe'"
if exist "%WORK%\pyrevit_setup.exe" ( "%WORK%\pyrevit_setup.exe" /VERYSILENT /SUPPRESSMSGBOXES /NORESTART /CURRENTUSER ) else ( echo   WARNING: pyRevit download failed - install manually from github.com/pyrevitlabs/pyRevit/releases )

:: 4) mcp package
echo [4/7] Installing Python dependency (mcp) ...
"%PY_EXE%" -m pip install --upgrade pip
"%PY_EXE%" -m pip install --upgrade "mcp>=1.2.0"

:: 5) MCP bridge script
echo [5/7] Installing MCP bridge to %SRVDIR% ...
if not exist "%SRVDIR%" mkdir "%SRVDIR%"
copy /Y "%~dp0revit_mcp_server.py" "%SRVDIR%\" >nul
copy /Y "%~dp0claude_desktop_config.sample.json" "%SRVDIR%\" >nul

:: 6) firewall (LAN only) - best effort without admin
echo [6/7] Firewall rule (only needed for LAN access) ...
netsh advfirewall firewall show rule name="pyRevit Routes 48884" >nul 2>&1
if errorlevel 1 (
  netsh advfirewall firewall add rule name="pyRevit Routes 48884" dir=in action=allow protocol=TCP localport=48884 >nul 2>&1
  if errorlevel 1 (
    echo   Not added ^(needs admin^). Single-PC/localhost setups don't need it.
    echo   For LAN access, run  firewall_lan.bat  once ^(it will prompt for admin^).
  ) else ( echo   Firewall rule added. )
) else ( echo   Firewall rule already present. )

:: 7) extension + routes + claude config (per-user)
echo [7/7] Installing extension, enabling Routes, writing Claude config ...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0configure.ps1" -Token "%TOKEN%" -RevitHost "%RHOST%" -PyExe "%PY_EXE%" -ServerDir "%SRVDIR%"

echo.
echo ============================================================
echo   Almost done - two steps that require the apps running:
echo ============================================================
echo   A) Open Revit -^> pyRevit tab -^> Reload  (loads the extension,
echo      starts Routes). Verify: http://localhost:48884/revit/ping
echo   B) Fully restart Claude Desktop, then ask it:  ping revit
echo.
echo   LAN access from another PC? run firewall_lan.bat once (admin prompt).
echo ============================================================
pause
endlocal
