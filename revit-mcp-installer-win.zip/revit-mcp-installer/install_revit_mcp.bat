@echo off
setlocal
:: Revit MCP Server installer - launcher.
:: RUN AS A NORMAL USER (do NOT "Run as administrator"): pyRevit installs per-user.
:: All work is done by install_revit_mcp.ps1 (with a log at %TEMP%\revitmcp_install.log).
::
:: Usage:  install_revit_mcp.bat [github_token] [revit_host]
::   token     - for the private extension (you'll be prompted if omitted)
::   revit_host- Claude->Revit host (default 127.0.0.1; use the Revit PC LAN IP for split)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_revit_mcp.ps1" %*

echo.
pause
endlocal
