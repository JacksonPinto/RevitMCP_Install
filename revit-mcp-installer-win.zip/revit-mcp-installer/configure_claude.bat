@echo off
setlocal
:: Repairs ONLY the Claude Desktop config (adds/updates the "revit" MCP server).
:: Writes UTF-8 without BOM. Run as a normal user.
:: Usage:  configure_claude.bat [revit_host]      (default host 127.0.0.1)
set "RHOST=%~1"
if "%RHOST%"=="" set "RHOST=127.0.0.1"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0configure_claude.ps1" -RevitHost "%RHOST%" -ServerDir "%USERPROFILE%\revit-mcp"
echo.
pause
endlocal
