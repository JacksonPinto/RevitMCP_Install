Revit MCP Server - Windows automated installer
==============================================

** RUN AS A NORMAL USER - DO NOT "Run as administrator" **
pyRevit installs per-user; running elevated breaks it. The installer refuses to
run if it detects admin rights. Just double-click install_revit_mcp.bat, or run
it from a plain (non-elevated) command prompt.

WHAT IT AUTOMATES (install_revit_mcp.bat -> configure.ps1)
  1. Downloads + silently installs Python 3.12.10 (per-user, added to PATH)
  2. Downloads + silently installs the latest signed pyRevit (per-user)
  3. Installs the Python "mcp" package
  4. Copies the MCP bridge (revit_mcp_server.py) to  %USERPROFILE%\revit-mcp\
  5. (LAN only) tries to add a firewall rule; if it can't (no admin), tells you
     to run firewall_lan.bat - see below
  6. Installs the PRIVATE RevitMCP extension (git clone with your token, or a
     tokened zipball download if git isn't present)
  7. Enables pyRevit Routes in pyRevit_config.ini (enabled, host 0.0.0.0, port 48884)
  8. Writes/merges the Claude Desktop config (adds an "revit" MCP server,
     keeping any servers you already have)

HOW TO RUN  (normal user - no admin)
  install_revit_mcp.bat  [github_token]  [revit_host]
    github_token : token for the private extension (prompted if omitted).
                   Request from jackson.pinto@wwt.com
    revit_host   : host Claude connects to. Default 127.0.0.1 (Claude + Revit on
                   the SAME PC). For a split setup pass this PC's LAN IP, e.g.:
                     install_revit_mcp.bat ghp_xxx 192.168.0.171

FIREWALL (LAN setups only) - firewall_lan.bat
  Only needed if Claude Desktop runs on a DIFFERENT machine. This one file needs
  admin, so it SELF-ELEVATES (single UAC prompt) and adds the inbound TCP 48884
  rule. Single-PC / localhost setups don't need it.

TWO STEPS THAT CANNOT BE AUTOMATED (the apps must be running)
  A) Open Revit -> pyRevit tab -> Reload  (loads the extension + starts Routes).
     Verify in a browser:  http://localhost:48884/revit/ping
  B) Fully restart Claude Desktop, then ask it:  ping revit

FILES
  install_revit_mcp.bat             - main installer (run as NORMAL user)
  firewall_lan.bat                  - optional, LAN only, self-elevates for the firewall rule
  configure.ps1                     - extension install + Routes enable + Claude config
  revit_mcp_server.py               - the MCP bridge
  claude_desktop_config.sample.json - reference config

EXECUTION POLICY / "SIGNED MODE"
  The .bat calls PowerShell with  -ExecutionPolicy Bypass  per process, so it runs
  without admin and is not blocked by the machine's script policy. No system policy
  change is made. If your environment requires Authenticode-signed scripts, sign
  install_revit_mcp.bat / configure.ps1 with your own code-signing certificate
  (Set-AuthenticodeSignature) - a signing cert cannot be bundled here.

NOTES
  - Windows 10/11 (has curl.exe + PowerShell), internet access, Revit 2025/2026 installed.
  - pyRevit uses an Inno Setup installer; if the silent flags fail, run the exe from
    %TEMP%\revitmcp_setup\ manually (choose the per-user / current-user option).
  - The routes have NO authentication. On host 0.0.0.0 any LAN machine can call them.
  - SSH (optional, for command-line git updates): ssh-keygen, add the .pub to GitHub,
    then  git remote set-url origin git@github.com:JacksonPinto/RevitMCP.extension.git

Contact: Jackson Pinto - jackson.pinto@wwt.com
