Revit MCP Server - Windows automated installer
==============================================

** RUN AS A NORMAL USER - DO NOT "Run as administrator" **
pyRevit installs per-user; elevating can break it. Just double-click
install_revit_mcp.bat (or run it from a normal command prompt).

WHY POWERSHELL: the installer logic is in install_revit_mcp.ps1 (the .bat only
launches it with -ExecutionPolicy Bypass). This avoids the silent failures that
batch scripts hit, and writes a full log to:  %TEMP%\revitmcp_install.log
If anything goes wrong, open that log - every step reports [OK]/[!].

WHAT IT AUTOMATES
  1. Downloads + installs Python 3.12.10 (per-user, PATH, pip)   [waits for completion]
  2. Downloads + installs the latest signed pyRevit (per-user)   [waits for completion]
  3. Installs the Python "mcp" package
  4. Copies revit_mcp_server.py to  %USERPROFILE%\revit-mcp\
  5. Installs the PRIVATE extension (git clone with your token, or tokened zipball)
  6. Enables pyRevit Routes in pyRevit_config.ini (enabled, host 0.0.0.0, port 48884)
  7. Writes/merges the Claude Desktop config (adds "revit"; keeps existing servers)
  8. Tries the firewall rule (LAN only) - see firewall_lan.bat if it can't (no admin)

HOW TO RUN  (normal user - no admin)
  install_revit_mcp.bat  [github_token]  [revit_host]
    github_token : token for the private extension (prompted if omitted).
                   Request from jackson.pinto@wwt.com
    revit_host   : host Claude connects to. Default 127.0.0.1 (Claude + Revit on
                   the SAME PC). Split setup -> pass this PC's LAN IP, e.g.:
                     install_revit_mcp.bat ghp_xxx 192.168.0.171

FIREWALL (LAN setups only) - firewall_lan.bat
  Only if Claude Desktop runs on a DIFFERENT machine. This one file self-elevates
  (single UAC prompt) and adds inbound TCP 48884. Single-PC setups don't need it.

TWO STEPS THAT NEED THE APPS RUNNING
  A) Open Revit -> pyRevit tab -> Reload  (loads extension + starts Routes).
     Verify:  http://localhost:48884/revit/ping
  B) Fully restart Claude Desktop, then ask:  ping revit

FILES
  install_revit_mcp.bat             - launcher (run as NORMAL user)
  install_revit_mcp.ps1             - the actual installer (logged)
  firewall_lan.bat                  - optional, LAN only, self-elevates for the firewall rule
  revit_mcp_server.py               - the MCP bridge
  claude_desktop_config.sample.json - reference config

TROUBLESHOOTING A SILENT / PARTIAL RUN
  - Open  %TEMP%\revitmcp_install.log  and look for [!] lines.
  - If pyRevit's silent install returns a non-zero code, run the downloaded exe in
    %TEMP%\revitmcp_setup\ manually and pick the per-user (current user) option.
  - If the extension step says "no token", re-run with your token, or add it in
    pyRevit -> Extensions (Git URL + token).

EXECUTION POLICY / SIGNING
  PowerShell runs with -ExecutionPolicy Bypass per process (no admin, no system change).
  For environments requiring signed scripts, sign install_revit_mcp.ps1 with your own
  code-signing certificate (Set-AuthenticodeSignature).

NOTES
  - Windows 10/11, internet access, Revit 2025/2026 installed.
  - The routes have NO authentication. On host 0.0.0.0 any LAN machine can call them.

Contact: Jackson Pinto - jackson.pinto@wwt.com
