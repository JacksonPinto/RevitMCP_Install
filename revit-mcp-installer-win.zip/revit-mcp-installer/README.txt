Revit MCP Server - Windows automated installer
==============================================

WHAT IT AUTOMATES (install_revit_mcp.bat -> configure.ps1)
  1. Downloads + silently installs Python 3.12.10 (per-user, added to PATH)
  2. Downloads + silently installs the latest signed pyRevit
  3. Installs the Python "mcp" package
  4. Copies the MCP bridge (revit_mcp_server.py) to  %USERPROFILE%\revit-mcp\
  5. Adds a Windows Firewall rule for inbound TCP 48884
  6. Installs the PRIVATE RevitMCP extension (git clone with your token, or a
     tokened zipball download if git isn't present)
  7. Enables pyRevit Routes in pyRevit_config.ini (enabled, host 0.0.0.0, port 48884)
  8. Writes/merges the Claude Desktop config (adds an "revit" MCP server,
     keeping any servers you already have)

HOW TO RUN  (RIGHT-CLICK -> Run as administrator)
  install_revit_mcp.bat  [github_token]  [revit_host]
    github_token : token for the private extension (you'll be prompted if omitted).
                   Request it from jackson.pinto@wwt.com
    revit_host   : the host Claude connects to. Default 127.0.0.1 (Claude + Revit
                   on the SAME PC). If Claude Desktop runs on another machine,
                   pass this PC's LAN IP, e.g.:  install_revit_mcp.bat ghp_xxx 192.168.0.171

TWO STEPS THAT CANNOT BE AUTOMATED (the apps must be running)
  A) Open Revit -> pyRevit tab -> Reload  (loads the extension + starts Routes).
     Verify in a browser:  http://localhost:48884/revit/ping
  B) Fully restart Claude Desktop, then ask it:  ping revit

FILES IN THIS FOLDER
  install_revit_mcp.bat            - orchestrator (run this as admin)
  configure.ps1                    - extension install + Routes enable + Claude config
  revit_mcp_server.py              - the MCP bridge script
  claude_desktop_config.sample.json- reference config

NOTES / TROUBLESHOOTING
  - Windows 10/11 (has curl.exe + PowerShell), internet access, Revit 2025/2026 installed.
  - pyRevit uses an Inno Setup installer; if the silent flags fail, run the exe from
    %TEMP%\revitmcp_setup\ manually.
  - The Routes-enable step writes pyRevit_config.ini best-effort; if Routes isn't on
    after Reload, toggle it in pyRevit -> Settings -> Routes (port 48884).
  - The routes have NO authentication. On host 0.0.0.0 any LAN machine can call them,
    including writes. Use a trusted network or add token auth for production.
  - SSH (optional, for command-line git updates of the extension): generate a key with
    ssh-keygen, add the .pub to GitHub, then
      git remote set-url origin git@github.com:JacksonPinto/RevitMCP.extension.git

Contact: Jackson Pinto - jackson.pinto@wwt.com
